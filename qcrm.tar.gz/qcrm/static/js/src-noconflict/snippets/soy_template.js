ace.define("ace/snippets/soy_template",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "soy_template";

});
